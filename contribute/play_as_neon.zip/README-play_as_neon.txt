Play as Neon
============

Thank you for donating to Open Surge!

Play as Neon is a gift made to our supporters, and you are one of them!

http://opensurge2d.org/contribute


How to play:
------------

1. Extract this package to the Open Surge folder
2. Launch Open Surge
3. Go to the Options Screen
4. Enter the Stage Select
5. Select "Play as Neon" and have fun!


Any questions? Reach out to our community at http://opensurge2d.org

- Alexandre Martins
  Developer of the Open Surge game engine
